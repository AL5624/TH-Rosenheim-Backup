package de.fhro.inf.its.uebung3;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class CryptoUtils {
    /**
     * generate a random byte array
     * @param numBytes  length of byte array
     * @return  byte array filled with random values
     */
    public static byte[] getRandomNonce(int numBytes) {
        byte[] nonce = new byte[numBytes];
        new SecureRandom().nextBytes(nonce);
        return nonce;
    }

    /**
     * generate an AES symmetric key with 256 bit length
     * @return AES key
     * @throws NoSuchAlgorithmException
     */
    public static SecretKey generateAESKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(256, new SecureRandom());
        return keyGen.generateKey();
    }

    /**
     * read data from a file and store it in an internal byte array
     *
     * @param srcFile  filename
     * @throws Exception
     * @return filecontent as byte array
     */
    public static byte[] readFromFile(String srcFile) throws Exception
    {
        return Files.readAllBytes(Paths.get(srcFile));
    }

    /**
     * read Base64 encoded file and decode it Base64
     *
     * @param inputFile   filename
     * @return decoded filecontent
     */
    public static byte[] readFromFileBase64(String inputFile)throws Exception
    {
        byte [] data = Files.readAllBytes(Paths.get(inputFile));
        return Base64.getDecoder().decode(data);
    }

    /**
     * store encrypted data base64 encoded in a file
     * @param destFile filename
     */
    public static void writeToFileBase64(String destFile, byte[] data) throws Exception
    {
        Path path = Paths.get(destFile);
        Files.write(path, Base64.getEncoder().encode(data));
    }
}

