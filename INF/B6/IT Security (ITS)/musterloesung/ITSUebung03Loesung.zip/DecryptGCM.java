package de.fhro.inf.its.uebung3;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Arrays;

public class DecryptGCM {
    private static final String CIPHER_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;   // 96 bit

    /**
     * Read a symmetric Key from a Keystore
     * Keystore is protected by a password
     * Key is protected by a password
     *
     * @pre Passwords for Keystore and Key are known
     * @post access to key for encryption and decryption
     *
     * @param keyStoreFile filename of keystore
     * @param keyStorePasswd password for keystore
     * @param keyAlias alias for secret key
     * @param keyPassword password for secret key
     * @return
     * @throws Exception
     */
    public static SecretKey readKey(String keyStoreFile, char[] keyStorePasswd, String keyAlias, char[] keyPassword) throws Exception {

        KeyStore ks = KeyStore.getInstance("JCEKS");
        FileInputStream in = new FileInputStream(keyStoreFile);
        ks.load(in, keyStorePasswd);     // load keyStore
        in.close();

        return (SecretKey) ks.getKey(keyAlias, keyPassword);   // get key from keystore
        // alternative solution to get key
        //KeyStore.SecretKeyEntry skEntry =
        //	    (KeyStore.SecretKeyEntry) ks.getEntry(keyAlias, new KeyStore.PasswordProtection(keyPassword));
        //return skEntry.getSecretKey();
    }

    /**
     * decrypt text with AES and GCM
     *
     * @param cipherText  ciphertext and IV
     * @param secret secret AES key
     * @return plaintext
     * @throws Exception
     */
     public static byte[] decrypt(byte[] cipherText, SecretKey secret) throws Exception {

        Cipher cipher = Cipher.getInstance(CIPHER_ALGO);
        byte[] iv = Arrays.copyOfRange(cipherText,0, IV_LENGTH_BYTE);
        cipher.init(Cipher.DECRYPT_MODE, secret, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
        byte[] aad = "Any Authentication Data".getBytes();
        cipher.updateAAD(aad);
        byte[] cText = Arrays.copyOfRange(cipherText, IV_LENGTH_BYTE, cipherText.length);
        return cipher.doFinal(cText);
    }
}
