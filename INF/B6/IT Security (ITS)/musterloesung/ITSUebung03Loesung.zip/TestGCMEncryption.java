package de.fhro.inf.its.uebung3;

import junit.framework.TestCase;

import javax.crypto.SecretKey;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.logging.Logger;

public class TestGCMEncryption extends TestCase {
    private static Logger logger = Logger.getLogger(TestGCMEncryption.class.getName());

    private static final String FILENAME = "test.txt";
    private static final String ENCTEXT = "encTest.txt";

    private static final String keyStoreFile = "./keystore";
    private static final String keyAlias = "PrivateKey";
    // Passwords for Keystore and Key
    // ATTENTION: in real application don't write passwords in source code,
    // they must be passed to the application by a secure way
    private static final char[] keyPassword = "Password".toCharArray();
    private static final char[] keyStorePasswd = "test".toCharArray();

    public void testEncryption(){
        encryption();
        decryption();
    }

    public void encryption(){
        try {
            byte[] data = CryptoUtils.readFromFile(FILENAME);
            SecretKey key = CryptoUtils.generateAESKey();
            byte[] encryptedData = EncryptGCM.encrypt(data, key);
            CryptoUtils.writeToFileBase64(ENCTEXT, encryptedData);
            EncryptGCM.saveKey(key,keyStoreFile,keyStorePasswd,keyAlias, keyPassword);
        } catch(Exception e) {
            logger.info("Error in encryption");
            logger.info(e.getMessage());
            fail();
        }
    }

    public void decryption(){
        byte[] decryptedData = null;
        byte[] fileContent = null;
        try {
            SecretKey key = DecryptGCM.readKey(keyStoreFile, keyStorePasswd, keyAlias, keyPassword);
            byte[] data = CryptoUtils.readFromFileBase64(ENCTEXT);
            decryptedData = DecryptGCM.decrypt(data,key);
            logger.info("Decrypted File: " + new String(decryptedData));
        } catch (Exception e) {
            logger.info("Error in decryption");
            logger.info(e.getMessage());
            fail();
        }

        // read original file and compare with result of encrypting and decrypting
        if (decryptedData != null) {
            try {
                fileContent = Files.readAllBytes(Paths.get(FILENAME));
            } catch (Exception e) {
                logger.info(e.getMessage());
            }
            assertTrue(Arrays.equals(decryptedData,fileContent));
            assertEquals(new String(decryptedData),new String(fileContent));
            logger.info("Decryption successful");
        }
    }
}
