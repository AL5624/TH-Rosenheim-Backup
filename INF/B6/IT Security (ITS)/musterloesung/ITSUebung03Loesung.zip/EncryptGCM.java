package de.fhro.inf.its.uebung3;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;

public class EncryptGCM {

    private static final String CIPHER_ALG = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;  // 16 Byte
    private static final int IV_LENGTH_BYTE = 12;   // 96 bit

    /**
     * encrypt data with AES and GCM
     * @param plainText
     * @param secret  AES key
     * @return encrypted data and IV
     * @throws Exception
     */
    public static byte[] encrypt(byte[] plainText, SecretKey secret) throws Exception {
        Cipher cipher = Cipher.getInstance(CIPHER_ALG);
        byte[] iv = CryptoUtils.getRandomNonce(IV_LENGTH_BYTE);
        cipher.init(Cipher.ENCRYPT_MODE, secret, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
        //Attention: Authentication data must be known at decryption and is not send/stored with the encrypted data
        // if no data is provided the MAC will be calculated only for the ciphertext
        byte[] aad = "Any Authentication Data".getBytes();
        cipher.updateAAD(aad);
        byte[] encryptedText = cipher.doFinal(plainText);
        return concatenateIvAndCipherText(iv, encryptedText);
    }

    /**
     * concatenate IV and ciphertext
     * @param iv
     * @param cipherText
     * @return  IV + ciphertext
     * @throws Exception
     */
    public static byte[] concatenateIvAndCipherText(byte[] iv, byte[] cipherText) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        output.write(iv);
        output.write(cipherText);
        return output.toByteArray();
    }

    /**
     * store key in a Keystore
     *
     * @param key   AES secret key
     * @param keyStoreFile filename of keystore
     * @param keyStorePasswd  password for keystore
     * @param keyAlias  alias for AES key
     * @param keyPassword password for AES key
     * @throws Exception
     */
    public static void saveKey(SecretKey key, String keyStoreFile, char[] keyStorePasswd, String keyAlias, char[] keyPassword) throws Exception {

        KeyStore ks = KeyStore.getInstance("JCEKS");
        ks.load(null, keyStorePasswd);          //init KeyStore instance

        ks.setKeyEntry(keyAlias, key, keyPassword, null);   //store Key in the object KeyStore
        // alternative solution for storing the key
        //KeyStore.SecretKeyEntry skEntry =
        //    new KeyStore.SecretKeyEntry((SecretKey) key);
        //ks.setEntry(keyAlias, skEntry, new KeyStore.PasswordProtection(keyPass));

        FileOutputStream fos = new FileOutputStream(keyStoreFile);
        ks.store(fos, keyStorePasswd);                  //store KeyStore in a file
        fos.close();
    }
}
