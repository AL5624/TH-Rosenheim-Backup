package de.fhro.inf.its.uebung04;

import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.Certificate;

/**
 * Class to Create an verify a digital signature with the algorithm
 * SHA-1 as hash-function for computing the digest
 * RSA for encryption
*/
public class DigitalSignature {

    /**
     * Sign the content of a file
     * 
     * @param filename    name of the file to be signed
     * @param signatureKey private key for signing
     * @return signature
     */
    public static byte[] sign(String filename, PrivateKey signatureKey) throws Exception
    {        
    	Signature sig = Signature.getInstance("SHA512withRSA");
    	// init signature with private key for signing
        sig.initSign(signatureKey);
        // read data and calculate Hash-value
        byte[] data = Files.readAllBytes(Paths.get(filename));
        sig.update(data);
        // make signature
        return sig.sign();
    }  

    /**
     * store signatur as Byte-Array in a file
     * 
     * @param sigFile  name of the file where the signature is stored
     * @param signedData signature
     */
    public static void saveSignature(String sigFile, byte[] signedData) throws Exception
    {
        FileOutputStream out = new FileOutputStream(sigFile);
        out.write(signedData);
        out.close();     
    }


    /**
     * verify a signature
     *
     * @param filename      name of the signed file
     * @param sigFilename   name of the file where the signature is stored
     * @return true if signatur correct, false if verification produces an error
     */
    public static boolean verify(String filename, String sigFilename, Certificate cert) throws Exception
    {
        boolean result = false;
        int len;
                
        Signature sig = Signature.getInstance("SHA512withRSA");
        // init signature with public key (stored in a certificate) for verifying
        sig.initVerify(cert);
        // alternative solution: sig.initVerify(cert.getPublicKey());

        // read file and calculate Message Digest
        byte[] data = Files.readAllBytes(Paths.get(filename));
        sig.update(data);
        // read the signature from file and init object signedData
        byte[] signedData = Files.readAllBytes(Paths.get(sigFilename));
        //verify the message digests and the signature
        result = sig.verify(signedData);

        return result;
    }


}
