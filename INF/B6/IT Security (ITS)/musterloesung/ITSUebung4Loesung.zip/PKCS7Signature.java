package de.fhro.inf.its.uebung04;

import sun.security.pkcs.ContentInfo;
import sun.security.pkcs.PKCS7;
import sun.security.pkcs.SignerInfo;
import sun.security.util.DerValue;
import sun.security.x509.AlgorithmId;
import sun.security.x509.X500Name;

import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

public class PKCS7Signature {
    /**
     * stores a digital signature in PKCS7 SignedData format in a file
     *
     * @param pkcs7File filename of file where signature is stored
     * @param cert  X509 Certificate of the signer
     * @param signedData signature
     */
    public static void createPKCS7(String pkcs7File, Certificate cert, byte[] signedData)  throws Exception
    {
        //load X500Name
        X500Name xName      = X500Name.asX500Name(((X509Certificate) cert).getSubjectX500Principal());
        //load serial number
        BigInteger serial   = ((X509Certificate) cert).getSerialNumber();
        //load digest algorithm
        AlgorithmId digestAlgorithmId = new AlgorithmId(AlgorithmId.SHA_oid);
        //load signing algorithm
        AlgorithmId signAlgorithmId = new AlgorithmId(AlgorithmId.RSAEncryption_oid);

        //Create SignerInfo:
        SignerInfo sInfo = new SignerInfo(xName, serial, digestAlgorithmId, signAlgorithmId, signedData);
        byte[] data = new byte[1024];
        //Create ContentInfo:
        ContentInfo cInfo = new ContentInfo(ContentInfo.DIGESTED_DATA_OID, new DerValue(DerValue.tag_OctetString, data));
        //Create PKCS7 Signed data
        PKCS7 p7 = new PKCS7(new AlgorithmId[] { digestAlgorithmId }, cInfo,
                new java.security.cert.X509Certificate[] { (X509Certificate) cert },
                new SignerInfo[] { sInfo });
        FileOutputStream out = new FileOutputStream(pkcs7File);
        PrintWriter pout = new PrintWriter(out);
        pout.print(p7.toString());
        pout.close();
    }
}
