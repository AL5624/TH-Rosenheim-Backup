﻿INHALT
1. Versionshistorie
2. Anmerkungen



1. Versionshistorie

* Vorlage erstellt 1.8.2013 - SJ



2. Anmerkungen
Das Makefile wird nur benötigt, wenn man den Übersetzungsprozess manuell anstoßen will.
Bei Verwendung von MikTex oder Texmaker einfach die Hauptdatei "thesis.tex" öffnen und
diese mit den integrierten Funktionen übersetzen.
