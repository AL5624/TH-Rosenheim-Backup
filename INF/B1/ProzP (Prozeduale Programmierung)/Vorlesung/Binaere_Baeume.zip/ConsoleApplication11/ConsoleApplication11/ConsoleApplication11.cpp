// ConsoleApplication11.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "ConsoleApplication11.h"
#include <malloc.h>
#include <stdio.h>

knoten * wurzel;

int main(){
	int eingabe;
	int n;
	int i;

	einfuegen(&wurzel, 50);
	einfuegen(&wurzel, 25);
	einfuegen(&wurzel, 75);
	einfuegen(&wurzel, 60);

	do {
		printf("Was moechten sie tun:\n");
		printf("0 - fertig\n");
		printf("1 - einfuegen\n");
		printf("2 - ausgeben\n");
		printf("3 - suchen\n");
		printf("4 - streichen\n");
		scanf("%d", &eingabe);
		switch (eingabe) {
		case 1:
			printf("Was soll eingefuegt werden?\n");
			scanf("%d", &n);
			einfuegen(&wurzel, n);
			break;
		case 2:
			ausgeben(wurzel, 0);
			break;
		case 3:
			printf("Was soll gesucht werden?\n");
			scanf("%d", &n);
			suchen(wurzel, n);
			break;
		case 4:
			printf("Was soll gestrichen werden?\n");
			scanf("%d", &n);
			streichen(&wurzel, n);
			break;
		}
	} while (eingabe != 0);

	return 0;
}

void einfuegen(knoten ** ppk, int n) {
	//Fall 1
	if (*ppk == NULL) {
		*ppk = (knoten *)malloc(sizeof(knoten));
		if (*ppk == NULL) return; //Fehler
		(**ppk).wert = n;
		(**ppk).links = (**ppk).rechts = NULL;
		return;
	}
	//Fall 2.1
	if((**ppk).wert < n)
		einfuegen(&(**ppk).rechts, n);
	else
	//Fall 2.2
	if ((**ppk).wert >= n)
		einfuegen(&(**ppk).links, n);
}

void streichen(knoten ** ppk, int n) {
	if (*ppk == NULL) { //Fall 1
		printf("%d wurde nicht gefunden und nicht gestrichen\n", n);
		return;
	}
	if ((**ppk).wert > n) {//Fall 2.1
		streichen(&(**ppk).links, n);
		return;
	}
	if ((**ppk).wert < n) {//Fall 2.2
		streichen(&(**ppk).rechts, n);
		return;
	}
	if ((**ppk).links == NULL && (**ppk).rechts == NULL) { //Fall 2.3.1
		free(*ppk);
		*ppk = NULL;
		printf("%d wurde gefunden und gestrichen\n", n);
		return;
	}
	if ((**ppk).links == NULL ) { //Fall 2.3.2
		knoten * tmp = *ppk;
		*ppk = (**ppk).rechts;
		free(tmp);
		tmp = NULL;
		printf("%d wurde gefunden und gestrichen\n", n);
		return;
	}
	if ((**ppk).rechts == NULL) { //Fall 2.3.3
		knoten * tmp = *ppk;
		*ppk = (**ppk).links;
		free(tmp);
		tmp = NULL;
		printf("%d wurde gefunden und gestrichen\n", n);
		return;
	}
	//Fall 2.3.4
	{
		int m = max_im_rechten_teilbaum((**ppk).rechts);
		(**ppk).wert = m;
		printf("%d wurde gefunden und durch %d ersetzt\n", n, m);
		streichen(&(**ppk).rechts, m);
	}
}

void suchen(knoten * pk, int n) {
	if (pk == NULL) {
		printf("%d wurde nicht gefunden\n", n);
		return;
	}
	if (pk->wert == n) {
		printf("%d wurde gefunden\n", n);
		return;
	}
	if (pk->wert > n)
		suchen(pk->links, n);
	else
		suchen(pk->rechts, n);
}

void ausgeben(knoten * pk, int einruecken) {
	int i;

	for (i = 0; i < einruecken; i++)
		printf("\t");

	if (pk == NULL)
		return;
	else {
		ausgeben(pk->links, einruecken + 1);
		printf("%d\n", pk->wert);
		ausgeben(pk->rechts, einruecken + 1);
	}
}

int max_im_rechten_teilbaum(knoten * pk) {
	if (pk->links == NULL)
		return pk->wert;
	else
		return max_im_rechten_teilbaum(pk->links);
}