#pragma once

struct knoten_s {
	int wert;
	struct knoten_s * links;
	struct knoten_s * rechts;
};

typedef struct knoten_s knoten;

void einfuegen(knoten ** ppk, int n);
void streichen(knoten ** ppk, int n);
void suchen(knoten * pk, int n);
void ausgeben(knoten * pk, int einruecken);
int max_im_rechten_teilbaum(knoten * pk);
