#include <stdio.h>  /* Standard Input/Output  z.B. scanf, printf */


int main (int argc, char *argv[]) 
{
}