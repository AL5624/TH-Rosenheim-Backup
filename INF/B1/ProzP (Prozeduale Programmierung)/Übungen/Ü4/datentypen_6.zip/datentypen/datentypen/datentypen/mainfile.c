/*******************************************************************
/ Programm    : Datentypen                                          
/ Verfasser   : Schmidt                                           
/ Datum       : Urprogramm: 17.10.2012                                          
/ Eingabe     : Vier Zeichen                            
/ Verarbeitung: diverse Berechnungen                   
/ �nderungen  : 17.10.2012
/*******************************************************************/

/* Einbinden von n�tigen Header-Dateien                               */
#include <stdio.h>    /* Standard Input/ Output  z.B. scanf, printf */
#include <stdlib.h>   /* Standard-Bibliothek, z.B. f�r system */

char kleinstesZeichen(char c1, char c2, char c3, char c4);
char groesstesZeichen(char c1, char c2, char c3, char c4);

int main()
{
	system("pause");
	return(0);
}

char kleinstesZeichen(char c1, char c2, char c3, char c4)
{
	char min;

	return min;
}

char groesstesZeichen(char c1, char c2, char c3, char c4)
{
	char max;

	return max;
}
