#ifndef _EXP_H_
#define _EXP_H_

/* Prototypen der ben�tigten Funktionen */

void strich (int n, char c); /* gibt n mal das Zeichen c aus  */
int grenzeEinlesen(int cMax);
void tabelleAusgeben(int grenze);


#endif
