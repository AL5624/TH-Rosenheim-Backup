//*******************************************************************
// Programm    : Dreieck                                          
// Verfasser   : Schmidt                                           
// Datum       : Urprogramm: 11.10.2012                                          
// Eingabe     : Seite + Winkel eines rechtwinkligen Dreiecks                            
// Verarbeitung: Berechnung aller Seiten und Winkel                   
// Ausgabe     : Ergebnis als Tabelle
// �nderungen  : 11.10.2012
//*******************************************************************

// Einbinden von n�tigen Header-Dateien                              
#include <stdio.h>    // Standard Input/ Output  z.B. scanf, printf
#include <stdlib.h>   // Standard-Bibliothek, z.B. f�r system
#include <math.h>     // Standard-Bibliothek f�r math. Funktionen z.B. sqrt
#include "mainfile.h" // eigene Header-Datei mit Funktionsprototypen


int main() // Beginn Hauptprogramm          **************************
{
	// Aufgabe: Dreieck
	dreieck();

	system("pause");
	return(0);
} //***************** Ende Hauptprogramm ***************************


// Definition der ben�tigten Funktionen      

void dreieck(void)
{
	double a;  // Seitenl�nge von Seite a
	double alpha_deg;  // Winkel in Grad

	// Dialoger�ffnung 
	strich(50,'-');
	printf ("Rechtwinkliges Dreieck\n");
	strich(50,'-');

	// Seite/Winkel einlesen
	printf("Bitte Laenge Seite a eingeben: ");
	scanf("%lf", &a);

	printf("Bitte Winkel Alpha in Grad eingeben: ");
	scanf("%lf", &alpha_deg);

	// Berechnung aller Seiten und Winkel
	// speichern aller Ergebnisse in einer neuen Variablen

	// abrunden aller Seiten auf die n�chste ganze Zahl

	// aufrunden aller Seiten auf die n�chste ganze Zahl

	// (korrektes) runden aller Seiten auf die n�chste ganze Zahl

	// Ausgabe aller Seiten und Winkel
	printf("       2 NK-Stellen   gerundet   abgerundet   aufgerundet\n");
	strich(57,'-');
	printf("a        %10.2f %10.0f   %10.0f    %10.0f\n", a, a, a, a);
}

// Eingabe: w_deg, Winkel in Grad
// Ausgabe: w_rad, Winkel in rad
double deg2rad(double w_deg)
{
	double w_rad = 0.0;
	// Grad in rad umrechnen, Ergebnis in w_rad

	return w_rad;
}

// gibt n mal das Zeichen c aus 
void strich (int n, char c) 
{
	int i;
	for (i=1; i<=n; i++)
		printf("%c", c);
	printf("\n");
}

