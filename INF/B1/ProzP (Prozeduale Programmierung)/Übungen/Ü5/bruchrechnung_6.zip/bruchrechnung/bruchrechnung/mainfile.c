/*******************************************************************
/ Programm    : Bruchrechnung                                         
/ Verfasser   : Schmidt                                           
/ Datum       : Urprogramm: 24.10.2012                                          
/ Eingabe     : 2 rationale Zahlen                          
/ Verarbeitung: diverse Berechnungen                   
/ �nderungen  : 24.10.2012
/ *******************************************************************/

/* Einbinden von n�tigen Header-Dateien                             */
#include <stdio.h>    /* Standard Input/ Output  z.B. scanf, printf */
#include <stdlib.h>   /* Standard-Bibliothek, z.B. f�r system       */
#include "mainfile.h"


int main()
{
	printf("Bitte Zaehler und Nenner Bruch 1 eingeben: ");

	system("pause");
	return(0);
}

