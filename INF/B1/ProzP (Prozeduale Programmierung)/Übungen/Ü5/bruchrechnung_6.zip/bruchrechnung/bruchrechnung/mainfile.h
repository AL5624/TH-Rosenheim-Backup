#ifndef _MAINFILE_H_
#define _MAINFILE_H_

/* Prototypen der ben�tigten Funktionen */


#endif
