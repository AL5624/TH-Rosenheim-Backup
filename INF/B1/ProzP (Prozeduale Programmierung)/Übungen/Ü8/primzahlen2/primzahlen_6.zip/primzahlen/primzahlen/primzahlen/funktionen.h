#ifndef _PRIM_H_
#define _PRIM_H_

/* Definition globale Konstanten  */
#define NICHT_PRIM 0
#define PRIM  1


/* Prototypen der ben�tigten Funktionen */
void strich (int n, char c); /* gibt n mal das Zeichen c aus  */


#endif
