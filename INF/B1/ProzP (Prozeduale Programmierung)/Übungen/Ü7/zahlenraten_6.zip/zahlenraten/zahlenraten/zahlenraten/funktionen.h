#ifndef _ZR_H_
#define _ZR_H_

/* Deklaration globale Konstanten f�r boolesche Ausdr�cke */
extern const int FALSE;
extern const int TRUE;

/* Prototypen der ben�tigten Funktionen */
void strich (int n, char c); /* gibt n mal das Zeichen c aus  */


#endif
