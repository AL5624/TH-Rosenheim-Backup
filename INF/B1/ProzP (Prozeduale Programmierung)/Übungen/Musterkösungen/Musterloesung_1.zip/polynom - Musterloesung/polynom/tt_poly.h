#ifndef TT_POLY_H
#define TT_POLY_H

void tt_polyWert(void);
void tt_polyAbl(void);

#endif
