/*******************************************************************
// Programm    : Polygon                                               
// Verfasser   : Schmidt                                             
// Datum       : Urprogramm: 5.12.2012                                           
// Aufgabe     : Berechnung Fl�che regelm��iger Polygone
// �nderungen  : 13.11.2012
*******************************************************************/

#include <stdio.h>  /* Standard Input/Output  z.B. scanf, printf */
#include <stdlib.h>   /* Standard-Bibliothek, z.B. f�r system       */
#include "funktionen.h"

int main(int argc, char **argv)    
{
	strich(50,'-');
	printf("Flaeche regelmaessiger Polygone\n");
	strich(50,'-');


	printf("\nServus! \n");
	system("pause");
	return 0;
}
