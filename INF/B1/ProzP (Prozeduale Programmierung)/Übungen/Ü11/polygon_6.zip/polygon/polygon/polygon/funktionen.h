#ifndef _POLY_H_
#define _POLY_H_


typedef enum
{
	CL_NOERROR,			/* Parameter sind g�ltig */
	CL_EMINOUTOFRANGE,	/* emin ist kleiner/gleich 2 */
	CL_EMAXOUTOFRANGE,	/* emax ist kleiner als emin */
	CL_RADIUSINVALID,	/* Radius ist kleiner/gleich 0.0 */
	CL_PARAMMISSING,	/* einer der Parameter emin/emax/r fehlt */
	CL_UNKOWNPARAM		/* ein nicht definierter String wurde in der Kommandozeile verwendet */
} cl_errors_t;

typedef enum
{
	FALSE,
	TRUE
} boolean_t;

/* Prototypen der ben�tigten Funktionen */
void strich (int n, char c); /* gibt n mal das Zeichen c aus  */

#endif
