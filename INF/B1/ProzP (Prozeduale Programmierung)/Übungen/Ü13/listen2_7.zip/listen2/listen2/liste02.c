//*********************************************************************
// Source File : liste02_0.c Einf�gemuster
// ADT f�r Verwaltung einer einfach verketteten Liste
// Verfasser   : R.Feindor / R.H�ttl
// Datum       : 18.02.2008
// �nderungen  : 11.1.2011 J. Schmidt
//*********************************************************************
#include "liste02.h"

// besetzt li vor (NULL-Pointer, anzahlZeilen=0 )
void initListe (t_Listenkopf *li)
{
   li->erstesElement = NULL;
   li->letztesElement = NULL;
   li->anzahlElemente = 0;
}

// erzeugt ein neues Element und fuegt es vorne ein
void pushFront(t_Listenkopf *li, const char *s)
{
   t_element *p;                                     // pointer
   p = (t_element*) malloc(sizeof(t_element));       // Speicher anfordern
   Assert(p != NULL, "kein Speicher bei malloc");     // pr�fen 
   strcpy (p->inhalt, s);                            // Element f�llen
   p->next = NULL;

   // vorn einf�gen:
   p->next = li->erstesElement;
   li->erstesElement = p;
   if (li->letztesElement == NULL) // wenn Liste bisher leer, sonst bleibt das letzte Element
      li->letztesElement = p;

   li->anzahlElemente++;
 }

// erzeugt ein neues Element und haengt es hinten an
void pushBack(t_Listenkopf *li, const char *s)
{
   t_element *p;                                     // pointer
   p = (t_element*) malloc(sizeof(t_element));       // Speicher anfordern
   Assert(p != NULL, "kein Speicher bei malloc");     // pr�fen 
   strcpy (p->inhalt, s);                            // Element f�llen
   p->next = NULL;

   // hinten anf�gen:
   if (li->erstesElement == NULL)  // wenn Liste bisher leer
   {
      li->erstesElement = li->letztesElement = p;
   }
   else
   {
      li->letztesElement->next = p;
      li->letztesElement = p;
   }

   li->anzahlElemente++;
}

// gibt das erste Element zur�ck und entfernt es aus li
void popFront(t_Listenkopf *li, char *s)
{
	t_element *p;
	if (li->erstesElement == NULL)   // Liste ist leer
	{
	  strcpy(s, NULLSTRING); // kein Speicher frei zu geben; nichts zu tun
	  return; 
	}

	strcpy(s,  li->erstesElement->inhalt);   // Inhalt kopieren
	// erstes Element abbauen:
	p = li->erstesElement;
	li->erstesElement = p->next;
	free (p);      
	li->anzahlElemente--;
	if (li->anzahlElemente == 0)
		li->letztesElement = NULL;

}

// gibt die Liste li am Bildschirm aus
void printListe(const t_Listenkopf *li)
{
   t_element *p;
   p= li->erstesElement;
   while (p != NULL)
   {
      printf("%s\n", p->inhalt);
      p = p->next;
   }
}



// ab hier Version 2                         *************************** V2

// erzeugt ein neues Element und f�gt es sortiert in li ein
void einfuegenElement(t_Listenkopf *li, const char *s)
{
   t_element *p;                                     // pointer
   p = (t_element*) malloc(sizeof(t_element));       // Speicher anfordern
   Assert(p != NULL, "kein Speicher bei malloc");     // pr�fen 
   strcpy (p->inhalt, s);                            // Element f�llen
   p->next = NULL;

   if (li->erstesElement == NULL) // Liste bisher leer
   {
      li->erstesElement = li->letztesElement = p;
   }
   else if (strcmp (li->erstesElement->inhalt , p->inhalt) > 0)    // vorn einf�gen
   {
      p->next = li->erstesElement;  
	  li->erstesElement = p;
   }
   else                                        // echt einf�gen
   {
      t_element *q = li->erstesElement;  // Hilfszeiger zum Durchwandern der Liste
      // solange noch ein Element kommt, dessen Inhalt < ist
      while ( (q->next != NULL) && (strcmp(q->next->inhalt, p->inhalt) < 0) )
            // Auswertung eines AND-Ausdrucks erfolgt von links
      {
         q = q->next;         // weitergehen
      }

      // jetzt sind wir an der richtigen Stelle
      if (q->next == NULL)    // falls am Ende:
         li->letztesElement = p;   

      p->next = q->next;  // Einketten
      q->next = p;
   }

   li->anzahlElemente++;
}

// l�scht das erste auftretende Element mit dem Inhalt s
// returncode = 0 bei geloescht, 1 falls nicht gefunden
int loeschenElement(t_Listenkopf *li, const char *s)
{
     // hier Code einf�gen 
}

// true, wenn die Elemente von li sortiert sind
bool ListeIsSorted (const t_Listenkopf *li)
{
   // hier Code einf�gen 
}



