//*********************************************************************
// Source File : tt_liste02.c
// Testtreiber f�r ADT liste (einfach verkettete Liste)
// Verfasser   : R.Feindor / R.H�ttl
// Datum       : 18.02.2008
// �nderungen  : 11.1.2011 J. Schmidt
//*********************************************************************
#include "liste02.h"

// Anzahl der Elemente
#define  N 10  

// falls man zusehen m�chte
//#define TEST     

char testListe[N][LAENGE];   // globale Testdaten N Elemente der Standard-LAENGE

// Generieren von zuf�lligen globalen Testdaten
void GenTestdaten() 
{	
   int i, z;
   srand((int) time(0)); // Start des Zufallsgenerators
   for (i = 0; i < N; i++)
   {
      z = rand() % (10 * N);    // Zufallszahl 0..10N
      sprintf (testListe[i], "Testelement %5i", z); // f�llen Elemente in testListe
   }
}

void testTeil3 (t_Listenkopf *li)
{
   printf("Testfall: einfuegen und loeschen\n");

   // hier Code einf�gen 

   #ifdef TEST
   system("pause");
   #endif
}

int main ()
{
   t_Listenkopf liste;

   GenTestdaten();
   initListe(&liste);
   printf("Testtreiber beginnt mit leerer Liste:\n");
   printListe(&liste);      
   testTeil3(&liste);      
   printf("Testtreiber erfolgreich beendet.");
   return (0);
}
