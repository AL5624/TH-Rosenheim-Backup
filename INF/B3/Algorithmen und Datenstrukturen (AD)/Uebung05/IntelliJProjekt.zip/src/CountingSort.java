public class CountingSort {

    /**
     * @param input integer array given as input
     * @param k     defines maximum integer value in input; all integers must in range [0..k]
     * @return input array is sorted in a stable (!!) manner
     */
    public static Integer[] sort(Integer[] input, Integer k) {
        Integer[] output = new Integer[input.length];    // array that will take sorted result.

	   //todo



       return output;
    }

}
