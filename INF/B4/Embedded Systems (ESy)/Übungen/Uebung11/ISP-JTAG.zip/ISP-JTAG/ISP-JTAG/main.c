/*
 * ISP-JTAG.c
 *
 * Created: 14.06.2018 10:01:09
 * Author : muwo522
 */ 


#ifndef F_CPU
#define F_CPU 16000000UL
#endif


#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>

#define FOSC 16000000
#define BAUD 9600
#define MYUBRR ((FOSC/(16UL * BAUD)-1))

volatile unsigned int counter = 0;						// counts how often button has been pressed


void uart_putchar(char c) {
	// Wait until data register empty.
	while (!(UCSR0A & (1 << UDRE0)));
	UDR0 = c;
}


int main(void)
	{
    // configure serial port / UART
    UBRR0L = (unsigned char) MYUBRR;			// set baud rate to 9600
    UBRR0H = (unsigned char) (MYUBRR >> 8);
    UCSR0B = (1<<TXEN0);						// enable transmitter
	UCSR0C =  (1<<UCSZ01) | (1<<UCSZ00);		// set frame format: 8 data bits, 1 stop bit

    // configure external interrupt INT0 / PD1
    EIMSK |= (1 << INT0);
    // set INT0 to trigger an any falling edge
    EICRA |= (1 << ISC01);	
    // globally activate interrupts in SREG (alternative: SREG |= 128)
    sei();	
	
	
	/* Replace with your application code */
    while (1) 
    {
		int i;
		char temp[20] = "\0";
		
		sprintf(temp, "%u", counter);
		for (i = 0; temp[i] != '\0'; i++) {
			uart_putchar(temp[i]);
		}
		uart_putchar('\n');
	}
}


ISR (INT0_vect)
{
 	counter++;
}
